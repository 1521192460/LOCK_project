#ifndef __RTC_H__
#define __RTC_H__
#include "main.h"
typedef struct rtc
{
	u16 year;
	u8 mon;
	u8 day;
	u8 week;
	u8 hour;
	u8 min;
	u8 sec;
	
}RTC_t;
extern RTC_t sys_time;
//�궨��

//��������
void clock_init(void);
void set_time_date(RTC_t time);
RTC_t get_time_date(void);
#endif
